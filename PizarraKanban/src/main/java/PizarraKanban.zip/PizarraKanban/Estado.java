
package PizarraKanban;

/**
 *
 * @author minu
 */
  public enum Estado {
    POR_HACER, EN_PROGRESO, COMPLETADO;
}

